const $ = id => document.getElementById(id);
let tasks = [];
let toastTimer;

function showToast(message, isError = false) {
  const toast = $("toast");
  toast.textContent = message;
  toast.className = isError ? "error" : "";
  toast.style.display = "block";
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => toast.style.display = "none", 3500);
}
async function api(url, options = {}) {
  const response = await fetch(url, {
    headers: { "Content-Type": "application/json" },
    ...options
  });
  const data = await response.json().catch(() => ({}));
  if (!response.ok) throw new Error(data.message || "Request failed.");
  return data;
}
function escapeHtml(value) {
  return String(value ?? "").replace(/[&<>"']/g, c => ({ "&":"&amp;", "<":"&lt;", ">":"&gt;", '"':"&quot;", "'":"&#39;" }[c]));
}
function formatDate(date) {
  if (!date) return "—";
  return new Date(date).toLocaleDateString("en-IN", { day: "2-digit", month: "short", year: "numeric", timeZone: "UTC" });
}
function updateStats() {
  const total = tasks.length;
  const pending = tasks.filter(t => t.status === "Pending").length;
  const inProgress = tasks.filter(t => t.status === "InProgress").length;
  const completed = tasks.filter(t => t.status === "Completed").length;
  $("totalCount").textContent = total;
  $("pendingCount").textContent = pending;
  $("progressCount").textContent = inProgress;
  $("completedCount").textContent = completed;
  const percentage = total ? Math.round(completed / total * 100) : 0;
  $("overallProgress").style.width = percentage + "%";
  $("progressText").textContent = percentage + "% completed";
  $("remainingText").textContent = `${total - completed} task(s) remaining`;
}
function renderTasks() {
  updateStats();
  const search = $("searchInput").value.trim().toLowerCase();
  const status = $("statusFilter").value;
  const priority = $("priorityFilter").value;
  const filtered = tasks.filter(task => {
    const matchesSearch = [task.title, task.description, task.assignedTo].some(v => String(v || "").toLowerCase().includes(search));
    return matchesSearch && (status === "All" || task.status === status) && (priority === "All" || task.priority === priority);
  });
  $("taskCountLabel").textContent = `${filtered.length} task(s) shown`;
  $("taskRows").innerHTML = filtered.length ? filtered.map(task => `
    <tr>
      <td><strong>${escapeHtml(task.title)}</strong><div class="description">${escapeHtml(task.description || "No description added")}</div></td>
      <td>${escapeHtml(task.assignedTo || "Unassigned")}</td>
      <td><span class="priority ${escapeHtml(task.priority)}">● ${escapeHtml(task.priority)}</span></td>
      <td>${formatDate(task.dueDate)}</td>
      <td><select class="status-select" data-status-id="${task._id}" aria-label="Change status for ${escapeHtml(task.title)}">
        <option value="Pending" ${task.status === "Pending" ? "selected" : ""}>Pending</option>
        <option value="InProgress" ${task.status === "InProgress" ? "selected" : ""}>In Progress</option>
        <option value="Completed" ${task.status === "Completed" ? "selected" : ""}>Completed</option>
      </select></td>
      <td><button class="delete-btn" data-delete-id="${task._id}">Delete</button></td>
    </tr>`).join("") : `<tr><td colspan="6" class="empty">${tasks.length ? "No tasks match your filters." : "No tasks yet. Click “Add new task” to create your first task."}</td></tr>`;
}
async function loadTasks() {
  try {
    tasks = await api("/api/tasks");
    renderTasks();
  } catch (err) {
    $("taskRows").innerHTML = `<tr><td colspan="6" class="empty">Could not load tasks. Make sure the server and MongoDB are running.</td></tr>`;
    showToast(err.message, true);
  }
}
function openModal() {
  $("taskForm").reset();
  $("modalBackdrop").classList.remove("hidden");
  $("taskTitle").focus();
}
function closeModal() { $("modalBackdrop").classList.add("hidden"); }
$("topAddBtn").addEventListener("click", openModal);
$("addTaskBtn").addEventListener("click", openModal);
$("closeModal").addEventListener("click", closeModal);
$("cancelModal").addEventListener("click", closeModal);
$("modalBackdrop").addEventListener("click", event => {
  if (event.target === $("modalBackdrop")) closeModal();
});
document.addEventListener("keydown", event => {
  if (event.key === "Escape") closeModal();
});

$("taskForm").addEventListener("submit", async event => {
  event.preventDefault();
  try {
    const task = await api("/api/tasks", { method: "POST", body: JSON.stringify({
      title: $("taskTitle").value.trim(),
      description: $("taskDescription").value.trim(),
      assignedTo: $("assignedTo").value.trim(),
      priority: $("taskPriority").value,
      dueDate: $("dueDate").value,
      status: $("taskStatus").value
    }) });
    closeModal();
    await loadTasks();
    showToast(`Task "${task.title}" created successfully.`);
  } catch (err) { showToast(err.message, true); }
});

$("taskRows").addEventListener("change", async event => {
  const select = event.target.closest("select[data-status-id]");
  if (!select) return;
  const id = select.dataset.statusId;
  select.disabled = true;
  try {
    const updated = await api(`/api/tasks/${id}/status`, {
      method: "PATCH", body: JSON.stringify({ status: select.value })
    });
    tasks = tasks.map(task => task._id === updated._id ? updated : task);
    renderTasks();
    showToast(`Task status changed to ${updated.status === "InProgress" ? "In Progress" : updated.status}.`);
  } catch (err) { showToast(err.message, true); await loadTasks(); }
});

$("taskRows").addEventListener("click", async event => {
  const button = event.target.closest("button[data-delete-id]");
  if (!button) return;
  const task = tasks.find(t => t._id === button.dataset.deleteId);
  if (!confirm(`Delete "${task?.title || "this task"}"?`)) return;
  button.disabled = true;
  try {
    await api(`/api/tasks/${button.dataset.deleteId}`, { method: "DELETE" });
    await loadTasks();
    showToast("Task deleted.");
  } catch (err) { showToast(err.message, true); button.disabled = false; }
});
$("searchInput").addEventListener("input", renderTasks);
$("statusFilter").addEventListener("change", renderTasks);
$("priorityFilter").addEventListener("change", renderTasks);

api("/api/health").then(data => {
  if (data.database !== "connected") showToast("MongoDB is not connected.", true);
}).catch(() => showToast("Start MongoDB and run npm start.", true));
loadTasks();
