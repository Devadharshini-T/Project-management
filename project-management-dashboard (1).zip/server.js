const express = require("express");
const mongoose = require("mongoose");
const path = require("path");
require("dotenv").config();

const app = express();
app.use(express.json());
app.use(express.static(path.join(__dirname, "public")));

const taskSchema = new mongoose.Schema({
  title: { type: String, required: true, trim: true, maxlength: 120 },
  description: { type: String, trim: true, maxlength: 1000, default: "" },
  assignedTo: { type: String, trim: true, maxlength: 80, default: "Unassigned" },
  priority: { type: String, enum: ["Low", "Medium", "High"], default: "Medium" },
  dueDate: { type: Date, default: null },
  status: { type: String, enum: ["Pending", "InProgress", "Completed"], default: "Pending" }
}, { timestamps: true });

const Task = mongoose.model("Task", taskSchema);

app.get("/api/health", (req, res) => {
  res.json({ ok: true, database: mongoose.connection.readyState === 1 ? "connected" : "disconnected" });
});

app.get("/api/tasks", async (req, res) => {
  try {
    const tasks = await Task.find().sort({ createdAt: -1 });
    res.json(tasks);
  } catch {
    res.status(500).json({ message: "Could not load tasks." });
  }
});

app.post("/api/tasks", async (req, res) => {
  try {
    const title = String(req.body.title || "").trim();
    if (!title) return res.status(400).json({ message: "Task title is required." });
    const status = req.body.status || "Pending";
    if (!["Pending", "InProgress", "Completed"].includes(status)) {
      return res.status(400).json({ message: "Choose a valid task status." });
    }
    const priority = req.body.priority || "Medium";
    if (!["Low", "Medium", "High"].includes(priority)) {
      return res.status(400).json({ message: "Choose a valid priority." });
    }
    let dueDate = null;
    if (req.body.dueDate) {
      dueDate = new Date(req.body.dueDate + "T00:00:00");
      if (Number.isNaN(dueDate.getTime())) return res.status(400).json({ message: "Choose a valid due date." });
    }
    const task = await Task.create({
      title,
      description: String(req.body.description || "").trim(),
      assignedTo: String(req.body.assignedTo || "").trim() || "Unassigned",
      priority,
      dueDate,
      status
    });
    res.status(201).json(task);
  } catch (err) {
    console.error(err);
    res.status(500).json({ message: "Could not create task." });
  }
});

app.patch("/api/tasks/:id/status", async (req, res) => {
  try {
    const status = req.body.status;
    if (!["Pending", "InProgress", "Completed"].includes(status)) {
      return res.status(400).json({ message: "Status must be Pending, InProgress, or Completed." });
    }
    const task = await Task.findByIdAndUpdate(
      req.params.id, { status }, { new: true, runValidators: true }
    );
    if (!task) return res.status(404).json({ message: "Task not found." });
    res.json(task);
  } catch {
    res.status(500).json({ message: "Could not update task status." });
  }
});

app.delete("/api/tasks/:id", async (req, res) => {
  try {
    const task = await Task.findByIdAndDelete(req.params.id);
    if (!task) return res.status(404).json({ message: "Task not found." });
    res.json({ message: "Task deleted successfully." });
  } catch {
    res.status(500).json({ message: "Could not delete task." });
  }
});

const PORT = process.env.PORT || 3001;
mongoose.connect(process.env.MONGODB_URI)
  .then(() => {
    console.log("Connected to MongoDB");
    app.listen(PORT, () => console.log(`Project Management Dashboard running at http://localhost:${PORT}`));
  })
  .catch(err => {
    console.error("MongoDB connection failed:", err.message);
    console.error("Check that MongoDB Server is installed and running, and MONGODB_URI in .env is correct.");
    process.exit(1);
  });